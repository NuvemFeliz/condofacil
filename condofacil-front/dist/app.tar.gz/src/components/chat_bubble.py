import flet as ft

class ChatBubble(ft.Stack):
    def __init__(self):
        super().__init__()
        self.chat_open = False
        self.chat_ui = ft.Column(
            visible=False,
            controls=[
                ft.Container(
                    width=300,
                    height=400,
                    bgcolor=ft.colors.WHITE,
                    border_radius=10,
                    content=ft.Column([
                        ft.Text("Assistente Virtual", weight="bold"),
                        ft.Divider(),
                        ft.ListView(expand=True),
                        ft.TextField(hint_text="Digite sua mensagem...")
                    ])
                )
            ]
        )
        
        self.controls = [
            ft.FloatingActionButton(
                icon=ft.icons.CHAT_BUBBLE_OUTLINE,
                bgcolor="#2563EB",
                on_click=self.toggle_chat
            ),
            self.chat_ui
        ]
    
    def toggle_chat(self, e):
        self.chat_open = not self.chat_open
        self.chat_ui.visible = self.chat_open
        self.update()