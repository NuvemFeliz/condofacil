import flet as ft
import os
from dotenv import load_dotenv

load_dotenv()

class WhatsAppButton(ft.FloatingActionButton):
    def __init__(self):
        super().__init__(
            icon=ft.icons.WHATSAPP,
            bgcolor="#25D366",
            shape=ft.CircleBorder(),
            mini=True,
            on_click=self.open_whatsapp
        )
    
    def open_whatsapp(self, e):
        phone = os.getenv("WHATSAPP_NUMBER")
        url = f"https://wa.me/{phone}"
        e.page.launch_url(url)